//-----------------------------------------------------------------------------
// Program Name: FFPLib_AlphaTest
// Program Desc: Alpha test function.
// Program Type: Vertex/Pixel shader
// Language: GLSL
//-----------------------------------------------------------------------------

//0 - CMPF_ALWAYS_FAIL,
//1 - CMPF_ALWAYS_PASS,
//2 - CMPF_LESS,
//3 - CMPF_LESS_EQUAL,
//4 - CMPF_EQUAL,
//5 - CMPF_NOT_EQUAL,
//6 - CMPF_GREATER_EQUAL,
//7 - CMPF_GREATER

bool Alpha_Func(in int func, in float alphaRef, in float alphaValue)
{
    if (func == 0) return false;                    // CMPF_ALWAYS_FAIL
    if (func == 2) return alphaValue < alphaRef;    // CMPF_LESS
    if (func == 3) return alphaValue <= alphaRef;   // CMPF_LESS_EQUAL
    if (func == 4) return alphaValue == alphaRef;   // CMPF_EQUAL
    if (func == 5) return alphaValue != alphaRef;   // CMPF_NOT_EQUAL
    if (func == 6) return alphaValue >= alphaRef;   // CMPF_GREATER_EQUAL
    if (func == 7) return alphaValue > alphaRef;    // CMPF_GREATER
    return true;                                    // CMPF_ALWAYS_PASS (and default)
}



void FFP_Alpha_Test(in float func, in float alphaRef, in vec4 texel)
{
    bool pass_ = Alpha_Func(int(func), alphaRef, texel.a);
    if (!pass_)
        discard;
}
